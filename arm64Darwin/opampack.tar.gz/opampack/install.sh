#!/bin/bash
export OPAMROOT=$PWD/opamroot
eval $(./opam env --root=$PWD/opamroot)
./opam install -y --assume-depexts ocaml.4.12.0 ocamlbuild zmq sexplib ppx_sexp_conv ppx_deriving getopt
