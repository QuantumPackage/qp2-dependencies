# Python argcomplete searches for this string. If found,
# it enables autocompletion
# PYTHON_ARGCOMPLETE_OK

from .bse_cli import run_bse_cli
from .bsecurate_cli import run_bsecurate_cli
