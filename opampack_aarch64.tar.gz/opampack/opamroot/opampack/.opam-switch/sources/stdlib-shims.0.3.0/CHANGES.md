0.3.0 2021-01-21 Cambridge
--------------------------

- Remove things accidentally included in 0.2.0 not listed below! (@dra27, #13)
- Extend the fix in #12 to OCaml 4.10.0, since PR#9011 wasn't merged until 4.11

0.2.0 2019-10-08 London
-----------------------

- Fix compilation with OCaml >= 4.07 under msvc (@dra27, #12, fixes #11)

0.1.0 2019-02-19 London
-----------------------

First release. In this release, only the `Stdlib` module is backported
to older version of OCaml.
