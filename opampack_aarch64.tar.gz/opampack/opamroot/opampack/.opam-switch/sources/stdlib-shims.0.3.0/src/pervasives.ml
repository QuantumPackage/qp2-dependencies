[@@@ocaml.deprecated "Use Stdlib instead."]

[@@@ocaml.warning "-3"]

include Stdlib.Pervasives
