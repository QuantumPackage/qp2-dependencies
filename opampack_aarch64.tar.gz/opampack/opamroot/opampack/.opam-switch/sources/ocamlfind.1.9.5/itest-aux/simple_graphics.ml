Graphics.open_graph "";

print_string "OK\n";;

