#remove_directory ".";;

