Compatibility Result module.

Projects that want to use the new result type defined in OCaml >= 4.03
while staying compatible with older version of OCaml should use the
`Result` module defined in this library.
