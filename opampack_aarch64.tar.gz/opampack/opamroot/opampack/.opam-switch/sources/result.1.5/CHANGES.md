1.5 (17/02/2020)
----------------

- Make Result an alias of Stdlib.Result on OCaml >= 4.08.

1.4 (27/03/2019)
----------------

- Switch to Dune.
- Do not refer to Pervasives; it is deprecated.

1.3 (05/02/2018)
----------------

- Switch to jbuilder.
