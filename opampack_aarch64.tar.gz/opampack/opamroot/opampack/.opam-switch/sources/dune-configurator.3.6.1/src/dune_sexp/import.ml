module Digest = Dune_digest
