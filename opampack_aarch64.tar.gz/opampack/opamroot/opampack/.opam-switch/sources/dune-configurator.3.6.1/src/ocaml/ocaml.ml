(** Modules to work with the OCaml toolchain and its compilation model *)

module Cm_kind = Cm_kind
module Mode = Mode
module Ml_kind = Ml_kind
module Variant = Variant
module Version = Version
