module Socket = Zmq_deferred.Socket.Make(Deferred)
