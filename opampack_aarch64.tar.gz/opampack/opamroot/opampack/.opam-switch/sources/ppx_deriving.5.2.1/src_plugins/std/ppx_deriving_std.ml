(* dummy module to appease dune and older version of OCaml *)
