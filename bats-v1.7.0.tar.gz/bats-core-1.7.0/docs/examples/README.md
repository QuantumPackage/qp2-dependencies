# Examples

This directory contains example .bats files.
See the [bats-core wiki][examples] for more details.

[examples]: https://github.com/bats-core/bats-core/wiki/Examples