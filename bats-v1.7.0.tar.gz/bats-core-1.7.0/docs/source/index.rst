Welcome to bats-core's documentation!
=====================================

Versions before v1.2.1 are documented over `there <https://github.com/bats-core/bats-core/blob/master/docs/versions.md>`_.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tutorial
   installation
   usage
   docker-usage
   writing-tests
   gotchas
   faq
   warnings/index
