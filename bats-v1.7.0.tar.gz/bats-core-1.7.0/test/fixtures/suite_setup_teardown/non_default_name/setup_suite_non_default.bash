setup_suite() {
    echo setup_suite non_default >> "$LOGFILE"
}

teardown_suite() {
    echo teardown_suite non_default >> "$LOGFILE"
}