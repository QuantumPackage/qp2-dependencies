setup_suite() {
    :
}

teardown_suite() {
    call-to-undefined-command
}