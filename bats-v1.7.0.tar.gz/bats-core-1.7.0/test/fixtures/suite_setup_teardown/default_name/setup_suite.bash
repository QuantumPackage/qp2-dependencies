setup_suite() {
    echo setup_suite >> "$LOGFILE"
}

teardown_suite() {
    echo teardown_suite >> "$LOGFILE"
}