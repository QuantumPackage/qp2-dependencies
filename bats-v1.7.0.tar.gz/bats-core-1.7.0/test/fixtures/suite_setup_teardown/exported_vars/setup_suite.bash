setup_suite() {
    export EXPORTED_VAR="${EXPECTED_VALUE?}"
}