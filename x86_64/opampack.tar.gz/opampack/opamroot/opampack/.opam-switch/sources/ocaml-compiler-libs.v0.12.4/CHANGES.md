v0.12.4
-------

- Make the build more reproducible (@jeremiedimino, fix #6)

v0.12.3
-------

- Update opam file

v0.12.2
-------

- Fix deprecation messages in `Ocaml_shadow` (fixes #7,
  @jeremiedimino)
