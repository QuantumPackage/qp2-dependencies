let () = Ppxlib.Location.raise_errorf "Raising inside the preprocessor"
