include Ocaml_common.Config
