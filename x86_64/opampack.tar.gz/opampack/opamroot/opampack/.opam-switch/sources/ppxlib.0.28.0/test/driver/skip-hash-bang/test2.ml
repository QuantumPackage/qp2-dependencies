#!ignored line

let () = print_endline "OK"
