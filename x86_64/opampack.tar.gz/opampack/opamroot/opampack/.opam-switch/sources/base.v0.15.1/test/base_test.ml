(*_ This library deliberately does not export anything. *)
