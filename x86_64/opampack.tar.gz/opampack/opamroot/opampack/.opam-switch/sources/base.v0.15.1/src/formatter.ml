type t = Caml.Format.formatter
