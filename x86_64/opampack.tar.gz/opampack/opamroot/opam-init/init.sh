if [ -t 0 ]; then
  test -r /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/complete.sh && . /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/complete.sh > /dev/null 2> /dev/null || true

  test -r /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/env_hook.sh && . /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/env_hook.sh > /dev/null 2> /dev/null || true
fi

test -r /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/variables.sh && . /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/variables.sh > /dev/null 2> /dev/null || true
