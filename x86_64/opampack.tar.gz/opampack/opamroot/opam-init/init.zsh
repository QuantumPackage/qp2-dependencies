if [[ -o interactive ]]; then
  [[ ! -r /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/complete.zsh ]] || source /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/complete.zsh  > /dev/null 2> /dev/null

  [[ ! -r /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/env_hook.zsh ]] || source /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/env_hook.zsh  > /dev/null 2> /dev/null
fi

[[ ! -r /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/variables.sh ]] || source /home/scemama/OpamPack/_build/opampack/opamroot/opam-init/variables.sh  > /dev/null 2> /dev/null
