# Prefix of the current opam switch
OPAM_SWITCH_PREFIX='/home/scemama/OpamPack/_build/opampack/opamroot/opampack'; export OPAM_SWITCH_PREFIX;
# Current opam switch man dir
MANPATH="$MANPATH":'/home/scemama/OpamPack/_build/opampack/opamroot/opampack/man'; export MANPATH;
# Binary dir for opam switch opampack
PATH='/home/scemama/OpamPack/_build/opampack/opamroot/opampack/bin':"$PATH"; export PATH;
