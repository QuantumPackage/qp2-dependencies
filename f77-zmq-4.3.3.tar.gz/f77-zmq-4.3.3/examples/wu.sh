#!/bin/bash

source shell_functions.sh

SERVER=./wuserver
CLIENT=./wuclient 

run
