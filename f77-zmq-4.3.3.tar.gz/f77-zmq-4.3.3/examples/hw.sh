#!/bin/bash

source shell_functions.sh

SERVER=./hwserver
CLIENT=./hwclient 

run
