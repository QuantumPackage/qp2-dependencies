#!/bin/bash

source shell_functions.sh

SERVER=./socket_monitor_server
CLIENT=./socket_monitor_client

run
