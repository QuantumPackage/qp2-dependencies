#!/bin/bash

source shell_functions.sh

SERVER=./hwserver_msg
CLIENT=./hwclient_msg

run
